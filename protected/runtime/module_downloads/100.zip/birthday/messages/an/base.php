<?php
return array (
  'Back to modules' => 'Zpět k modulům',
  'Birthday Module Configuration' => '',
  'No birthday.' => '',
  'Save' => 'Uložit',
  'The number of days future bithdays will be shown within.' => '',
  'Tomorrow' => '',
  'Upcoming' => '',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes' => '',
  'birthdays' => '',
  'days' => '',
  'in' => '',
  'today' => '',
  'years old.' => '',
);
