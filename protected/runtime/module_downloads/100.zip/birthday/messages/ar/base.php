<?php
return array (
  'Back to modules' => 'عودة للموديولات',
  'Birthday Module Configuration' => 'إعدادات موديول عيد الميلاد',
  'No birthday.' => 'لا يوجد عيد ميلاد.',
  'Save' => 'حفظ',
  'The number of days future bithdays will be shown within.' => 'عدد الأيام التي تُعرض فيها مناسبة عيد الميلاد',
  'Tomorrow' => 'غداً',
  'Upcoming' => 'قادم',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'يمكنك تحديد عدد الأيام التي يظهر في إشعار بقرب عيد الميلاد',
  'becomes' => 'يصبح',
  'birthdays' => 'ايام الميلاد',
  'days' => 'أيام',
  'in' => 'في',
  'today' => 'اليوم',
  'years old.' => 'سنوات من العمر',
);
