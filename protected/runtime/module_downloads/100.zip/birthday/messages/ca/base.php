<?php
return array (
  'Back to modules' => 'Torna al mòduls',
  'Birthday Module Configuration' => '',
  'No birthday.' => '',
  'Save' => 'Desa',
  'The number of days future bithdays will be shown within.' => '',
  'Tomorrow' => '',
  'Upcoming' => '',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes' => '',
  'birthdays' => '',
  'days' => '',
  'in' => 'a',
  'today' => '',
  'years old.' => '',
);
