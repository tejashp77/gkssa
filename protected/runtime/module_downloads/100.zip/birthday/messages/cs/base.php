<?php
return array (
  'Back to modules' => 'Zpět na přehled modulů',
  'Birthday Module Configuration' => 'Nastavení modulu Narozeniny',
  'No birthday.' => 'Žádné narozeniny.',
  'Save' => 'Uložit',
  'The number of days future bithdays will be shown within.' => 'Počet dnů v budoucnosti, ve kterých se budou zobrazovat narozeniny.',
  'Tomorrow' => 'Zítra',
  'Upcoming' => 'Nadcházející',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Můžete nastavit počet dnů před narozeninami, kdy na ně bude upozorněno.',
  'becomes' => 'bude',
  'birthdays' => 'narozeniny',
  'days' => 'dnů',
  'in' => 'za',
  'today' => 'dnes',
  'years old.' => 'let.',
);
