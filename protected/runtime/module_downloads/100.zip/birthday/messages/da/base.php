<?php
return array (
  'Back to modules' => 'Tilbage til moduler',
  'Birthday Module Configuration' => 'Fødselsdag Modul konfiguration',
  'No birthday.' => 'Ingen fødselsdag.',
  'Save' => 'Gem',
  'The number of days future bithdays will be shown within.' => 'Antallet af dage fremtidige fødselsdage vil blive vist.',
  'Tomorrow' => 'Imorgen',
  'Upcoming' => 'Kommende',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kan indstille, antallet af dage som vises  i kommende fødselsdage.',
  'becomes' => 'bliver',
  'birthdays' => 'fødselsdage',
  'days' => 'dage',
  'in' => 'i',
  'today' => 'i dag',
  'years old.' => 'år gammel.',
);
