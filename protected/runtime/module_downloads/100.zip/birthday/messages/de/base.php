<?php
return array (
  'Back to modules' => 'Zurück zu den Modulen',
  'Birthday Module Configuration' => 'Konfiguration Geburtstagsmodul',
  'No birthday.' => 'Kein Geburtstag.',
  'Save' => 'Speichern',
  'The number of days future bithdays will be shown within.' => 'Anzahl an Tagen, an denen zukünftige Geburtstage bereits angezeigt werden.',
  'Tomorrow' => 'Morgen',
  'Upcoming' => 'Demnächst',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kannst die Anzahl an Tagen einstellen, an denen zukünftige Geburstage bereits angezeigt werden.',
  'becomes' => 'wird',
  'birthdays' => 'Geburtstage',
  'days' => 'Tage',
  'in' => 'in',
  'today' => 'heute',
  'years old.' => 'Jahre alt.',
);
