<?php
return array (
  'Back to modules' => 'Volver a módulos',
  'Birthday Module Configuration' => 'Configuración del módulo Cumpleaños',
  'No birthday.' => 'Sin cumpleaños.',
  'Save' => 'Guardar',
  'The number of days future bithdays will be shown within.' => 'Número de días para mostrar los siguientes cumpleaños.',
  'Tomorrow' => 'Mañana',
  'Upcoming' => 'Próximo',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Debes configurar el número de días para mostrar los cumpleaños.',
  'becomes' => 'cumple',
  'birthdays' => 'cumpleaños',
  'days' => 'días',
  'in' => 'en',
  'today' => 'hoy',
  'years old.' => 'años',
);
