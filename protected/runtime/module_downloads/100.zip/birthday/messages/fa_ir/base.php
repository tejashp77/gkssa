<?php
return array (
  'Back to modules' => 'بازگشت‌ به ماژول‌‌ها',
  'Birthday Module Configuration' => 'پیکربندی ماژول زادروز',
  'No birthday.' => 'زادروزی وجود ندارد.',
  'Save' => 'ذخیره',
  'The number of days future bithdays will be shown within.' => 'تعداد روزهایی که زادروز، قبل از فرا رسیدن یادآوری می‌شود.',
  'Tomorrow' => 'فردا',
  'Upcoming' => 'نزدیک',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'شما می‌توانید تعداد روزهایی که زادروزهای نزدیک یادآوری می‌شوند تنظیم کنید. ',
  'becomes' => 'می‌شود.',
  'birthdays' => 'زادروزها',
  'days' => 'روز',
  'in' => 'در',
  'today' => 'امروز',
  'years old.' => 'ساله',
);
