<?php
return array (
  'Back to modules' => 'Retour aux modules',
  'Birthday Module Configuration' => 'Configuration du module Anniversaire',
  'No birthday.' => 'Aucun anniversaire.',
  'Save' => 'Enregistrer',
  'The number of days future bithdays will be shown within.' => 'Le nombre de jours avant qu\'un anniversaire soit affiché.',
  'Tomorrow' => 'Demain',
  'Upcoming' => 'Prochainement',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Vous pouvez spécifier le nombre de jours avant qu\'un anniversaire soit affiché.',
  'becomes' => 'aura',
  'birthdays' => 'anniversaires',
  'days' => 'jours',
  'in' => 'dans',
  'today' => 'aujourd\'hui',
  'years old.' => 'ans.',
);
