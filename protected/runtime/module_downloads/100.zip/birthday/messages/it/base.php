<?php
return array (
  'Back to modules' => 'Indietro ai moduli',
  'Birthday Module Configuration' => 'Configurazioni Modulo Compleanno',
  'No birthday.' => 'Nessun compleanno.',
  'Save' => 'Salva',
  'The number of days future bithdays will be shown within.' => 'Quanti giorni prima del compleanno visualizzare la notifica',
  'Tomorrow' => 'Domani',
  'Upcoming' => 'In arrivo',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes' => 'diventa',
  'birthdays' => 'compleanni',
  'days' => 'giorni',
  'in' => 'in',
  'today' => 'oggi',
  'years old.' => 'anni.',
);
