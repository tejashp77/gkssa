<?php
return array (
  'Back to modules' => 'Atgal į modulius',
  'Birthday Module Configuration' => 'Gimimo dienos modulio konfigūracija',
  'No birthday.' => 'Nėra gimimo dienos.',
  'Save' => 'Išsaugoti',
  'The number of days future bithdays will be shown within.' => 'Dienų skaičius, per kurias bus rodomi artėjantys gimtadieniai',
  'Tomorrow' => 'Rytoj',
  'Upcoming' => 'Artėjantis',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Per rodomus artėjančius gimtadienius Jūs galite konfigūruoti dienų skaičių.',
  'becomes' => 'artėja',
  'birthdays' => 'gimimo dienos',
  'days' => 'Dienos',
  'in' => 'į',
  'today' => 'šiandien',
  'years old.' => 'Amžiaus.',
);
