<?php
return array (
  'Back to modules' => 'Terug naar modules',
  'Birthday Module Configuration' => 'Verjaardagen module configuratie',
  'No birthday.' => 'Geen verjaardagen.',
  'Save' => 'Opslaan',
  'The number of days future bithdays will be shown within.' => 'Het aantal dagen waarin toekomstige verjaardagen getoond worden.',
  'Tomorrow' => 'Morgen',
  'Upcoming' => 'Aankomende',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'U kunt het aantal dagen waarin toekomstige verjaardagen getoond worden instellen.',
  'becomes' => 'wordt',
  'birthdays' => 'verjaardagen',
  'days' => 'dagen',
  'in' => 'binnen',
  'today' => 'vandaag',
  'years old.' => 'jaar oud.',
);
