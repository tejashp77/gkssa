<?php
return array (
  'Back to modules' => 'Powrót do modułów',
  'Birthday Module Configuration' => 'Konfiguracja modułu Birthday',
  'No birthday.' => 'Nie ma urodzin.',
  'Save' => 'Zapisz',
  'The number of days future bithdays will be shown within.' => 'Liczba dni naprzód kiedy dzień urodzin będzie się wyświetlał. ',
  'Tomorrow' => 'Jutro',
  'Upcoming' => 'Nadchodzące ',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Możesz skonfigurować liczbę dni kiedy będą pokazywane nadchodzące urodziny.',
  'becomes' => 'będzie miał',
  'birthdays' => 'urodziny',
  'days' => 'dni',
  'in' => 'w',
  'today' => 'dzisiaj',
  'years old.' => 'lat.',
);
