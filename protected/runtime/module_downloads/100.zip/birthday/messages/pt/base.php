<?php
return array (
  'Back to modules' => 'Voltar para os módulos',
  'Birthday Module Configuration' => '',
  'No birthday.' => '',
  'Save' => 'Guardar',
  'The number of days future bithdays will be shown within.' => '',
  'Tomorrow' => '',
  'Upcoming' => '',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes' => '',
  'birthdays' => '',
  'days' => '',
  'in' => '',
  'today' => '',
  'years old.' => '',
);
