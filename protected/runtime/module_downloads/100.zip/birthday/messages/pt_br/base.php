<?php
return array (
  'Back to modules' => 'Voltar aos módulos',
  'Birthday Module Configuration' => 'Configuração do Módulo de Aniversário',
  'No birthday.' => 'Nenhum aniversariante.',
  'Save' => 'Salvar',
  'The number of days future bithdays will be shown within.' => 'O número de dias para exibição dos próximos aniversários no calendário.',
  'Tomorrow' => 'Amanhã',
  'Upcoming' => 'Próximos',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Você pode configurar o número de dias antes dos próximos aniversários para que sejam mostrados no calendário.',
  'becomes' => 'tornar-se',
  'birthdays' => 'aniversários',
  'days' => 'dias',
  'in' => 'em',
  'today' => 'hoje',
  'years old.' => 'anos de idade.',
);
