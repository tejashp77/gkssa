<?php
return array (
  'Back to modules' => 'Înapoi la module',
  'Birthday Module Configuration' => 'Configurare Modul Aniversări',
  'No birthday.' => 'Nici o aniversare.',
  'Save' => 'Salvează',
  'The number of days future bithdays will be shown within.' => 'Numărul zilelor afișate în aniversările viitoare.',
  'Tomorrow' => 'Mâine',
  'Upcoming' => 'Viitoare',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Poți configura numărul zilelor în care aniversările viitoare vor fi afișate.',
  'becomes' => 'devine',
  'birthdays' => 'aniversări',
  'days' => 'zile',
  'in' => 'în',
  'today' => 'azi',
  'years old.' => 'de ani.',
);
