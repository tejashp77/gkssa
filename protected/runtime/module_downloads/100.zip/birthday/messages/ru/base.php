<?php
return array (
  'Back to modules' => 'Назад к модулям',
  'Birthday Module Configuration' => 'Настройки модуля День рождения',
  'No birthday.' => 'Сегодня никто не празднует день рождения.',
  'Save' => 'Сохранить',
  'The number of days future bithdays will be shown within.' => 'Количество отображаемых в блоке дней рождения.',
  'Tomorrow' => 'Завтра',
  'Upcoming' => 'Предстоящие',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Вы можете настроить количество предстоящих дней рождения для отображения в блоке.',
  'becomes' => 'исполняется',
  'birthdays' => 'дни рождения',
  'days' => 'дня',
  'in' => 'через',
  'today' => 'сегодня',
  'years old.' => 'лет.',
);
