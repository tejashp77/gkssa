<?php
return array (
  'Back to modules' => 'Modüllere dön',
  'Birthday Module Configuration' => '',
  'No birthday.' => 'Hiçbir doğum günü yok.',
  'Save' => 'Kaydet',
  'The number of days future bithdays will be shown within.' => '',
  'Tomorrow' => 'Yarın',
  'Upcoming' => 'Yaklaşan',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes' => 'olur',
  'birthdays' => 'doğum günü',
  'days' => 'Günler',
  'in' => '',
  'today' => 'bugün',
  'years old.' => 'yaşında.',
);
