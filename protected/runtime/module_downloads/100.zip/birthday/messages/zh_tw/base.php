<?php
return array (
  'Back to modules' => '',
  'Birthday Module Configuration' => '生日模組設定',
  'No birthday.' => '無生日資料',
  'Save' => '儲存',
  'The number of days future bithdays will be shown within.' => '多少天前會通知生日',
  'Tomorrow' => '明天',
  'Upcoming' => '即將到來',
  'You may configure the number of days within the upcoming birthdays are shown.' => '您可設定多少天前會通知即將到來的生日',
  'becomes' => '成為',
  'birthdays' => '生日',
  'days' => '天',
  'in' => '即將在',
  'today' => '今天',
  'years old.' => '歲',
);
