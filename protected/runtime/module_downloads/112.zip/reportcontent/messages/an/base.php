<?php
return array (
  'Manage <strong>reported posts</strong>' => '',
  'Reported posts' => '',
  'by :displayName' => '',
);
