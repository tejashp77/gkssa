<?php
return array (
  'Here you can manage reported users posts.' => '',
);
