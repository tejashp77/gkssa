<?php
return array (
  'Appropriate' => '',
  'Content' => '',
  'Delete post' => '',
  'Reason' => '',
  'Reporter' => '',
);
