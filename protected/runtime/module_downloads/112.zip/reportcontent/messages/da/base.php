<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Administrer <strong>anmeldte opslag</strong>',
  'Reported posts' => 'Anmeldte opslag',
  'by :displayName' => 'af :displayName',
);
