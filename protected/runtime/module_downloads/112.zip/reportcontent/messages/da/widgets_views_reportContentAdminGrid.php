<?php
return array (
  'Appropriate' => 'Passende',
  'Content' => 'Indhold',
  'Delete post' => 'Slet opslag',
  'Reason' => 'Grundlag',
  'Reporter' => 'Anmelder',
);
