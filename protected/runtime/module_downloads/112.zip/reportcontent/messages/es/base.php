<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Administrar <strong>entradas reportadas</strong>',
  'Reported posts' => 'Entradas reportadas',
  'by :displayName' => 'por :displayName',
);
