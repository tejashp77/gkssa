<?php
return array (
  'Doesn\'t belong to space' => 'No pertenece a este espacio',
  'Offensive' => 'Ofensivo',
  'Spam' => 'Spam',
);
