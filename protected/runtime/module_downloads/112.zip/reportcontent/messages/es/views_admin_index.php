<?php
return array (
  'Here you can manage reported users posts.' => 'Aquí puedes administrar las entradas de usuario reportadas.',
);
