<?php
return array (
  'Appropriate' => 'Apropiado',
  'Content' => 'Contenido',
  'Delete post' => 'Eliminar entrada',
  'Reason' => 'Razón',
  'Reporter' => 'Reportador',
);
