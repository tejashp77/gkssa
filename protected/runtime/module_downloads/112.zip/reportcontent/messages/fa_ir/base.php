<?php
return array (
  'Manage <strong>reported posts</strong>' => 'مدیریت <strong>پست‌های گزارش‌شده</strong>',
  'Reported posts' => 'پست‌های گزارش‌شده',
  'by :displayName' => 'توسط: displayName',
);
