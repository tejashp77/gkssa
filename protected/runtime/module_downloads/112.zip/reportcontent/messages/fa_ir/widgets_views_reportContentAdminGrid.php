<?php
return array (
  'Appropriate' => 'مناسب',
  'Content' => 'محتوا',
  'Delete post' => 'حذف پست',
  'Reason' => 'علت',
  'Reporter' => 'گزارش‌کننده',
);
