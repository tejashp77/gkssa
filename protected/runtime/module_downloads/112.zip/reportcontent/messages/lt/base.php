<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Tvarkyti <strong>skelbimus, apie kuriuos pranešė</strong>',
  'Reported posts' => 'Skelbimai, apie kuriuos pranešė',
  'by :displayName' => '(kieno) :displayName',
);
