<?php
return array (
  'Appropriate' => 'Tinkamas',
  'Content' => 'Turinys',
  'Delete post' => 'Ištrinti skelbimą',
  'Reason' => 'Priežastis',
  'Reporter' => 'Pranešėjas',
);
