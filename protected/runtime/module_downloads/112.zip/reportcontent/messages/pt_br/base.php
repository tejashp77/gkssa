<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Gerenciar <strong>posts reportados</strong>',
  'Reported posts' => 'Posts reportados',
  'by :displayName' => 'por :displayName',
);
