<?php
return array (
  'Appropriate' => 'Apropriado',
  'Content' => 'Conteúdo',
  'Delete post' => 'Apagar postagem',
  'Reason' => 'Motivo',
  'Reporter' => 'Relator',
);
