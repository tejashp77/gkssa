<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Управление <strong>репортами</strong>',
  'Reported posts' => 'Репорты',
  'by :displayName' => 'by :displayName',
);
