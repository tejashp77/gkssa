<?php
return array (
  'Appropriate' => 'Соответствующий',
  'Content' => 'Содержание',
  'Delete post' => 'Удалить сообщение',
  'Reason' => 'Причина',
  'Reporter' => 'Репорт',
);
