<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Yönet <strong>bildirilen mesajlar</strong>',
  'Reported posts' => 'Bildirilen mesajlar',
  'by :displayName' => 'tarafından :displayName',
);
