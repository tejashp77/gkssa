<?php
return array (
  'Doesn\'t belong to space' => 'Mekana ait değil',
  'Offensive' => 'Saldırgan',
  'Spam' => 'Spam',
);
