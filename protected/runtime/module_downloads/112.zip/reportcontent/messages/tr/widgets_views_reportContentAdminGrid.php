<?php
return array (
  'Appropriate' => 'Uygun',
  'Content' => 'İçerik',
  'Delete post' => 'Mesajı sil',
  'Reason' => 'Neden',
  'Reporter' => 'Tarafından',
);
