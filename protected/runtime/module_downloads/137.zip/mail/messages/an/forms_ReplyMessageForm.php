<?php
return array (
  'Message' => 'Zpráva',
);
