<?php
return array (
  'Close' => 'اغلاق',
  'New message' => 'رسالة جديدة',
  'Send' => 'ارسال',
);
