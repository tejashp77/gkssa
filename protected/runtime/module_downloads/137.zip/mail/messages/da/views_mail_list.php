<?php
return array (
  'There are no messages yet.' => 'Der er ingen beskeder endnu.',
);
