<?php
return array (
  'New message from {senderName}' => 'Neue Nachricht von {senderName}',
  'and {counter} other users' => 'und {counter} weiteren Nutzern',
);
