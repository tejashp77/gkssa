<?php
return array (
  'New message in discussion from %displayName%' => 'Neue Nachricht in der Diskussion von %displayName%',
);
