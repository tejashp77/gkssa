<?php
return array (
  'New message from {senderName}' => 'Nuevo mensaje de {senderName}',
  'and {counter} other users' => 'y otros {counter} usuarios',
);
