<?php
return array (
  'Groups' => 'گروه‌ها',
  'Members' => 'اعضا',
  'Spaces' => 'انجمن‌ها',
  'User Posts' => 'پست‌های کاربران',
);
