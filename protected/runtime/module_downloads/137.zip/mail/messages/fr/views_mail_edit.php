<?php
return array (
  'Edit message entry' => 'Modifier le message',
  'Save' => 'Enregistrer',
);
