<?php
return array (
  'There are no messages yet.' => 'Il n\'y a aucun message.',
);
