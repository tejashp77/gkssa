<?php
return array (
  'New message' => 'Nouveau message',
  'Send message' => 'Envoyer le message',
);
