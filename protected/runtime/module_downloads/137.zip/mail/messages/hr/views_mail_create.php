<?php
return array (
  'Close' => '',
  'New message' => '',
  'Send' => '',
);
