<?php
return array (
  'Messages' => '',
  'New message' => '',
  'Show all messages' => '',
);
