<?php
return array (
  'New message from {senderName}' => 'Nuovo messaggio da {senderName}',
  'and {counter} other users' => 'e {counter} altri utenti',
);
