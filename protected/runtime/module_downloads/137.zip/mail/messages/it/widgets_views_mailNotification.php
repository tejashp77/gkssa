<?php
return array (
  'Messages' => 'Messaggi',
  'New message' => 'Nuovo messaggio',
  'Show all messages' => 'Mostra tutti i messaggi',
);
