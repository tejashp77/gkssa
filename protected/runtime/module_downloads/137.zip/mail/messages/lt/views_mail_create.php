<?php
return array (
  'Close' => 'Uždaryti',
  'New message' => 'Nauja Žinutė',
  'Send' => 'Išsiųsti',
);
