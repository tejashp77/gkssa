<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Patvirtinti</strong> pokalbio pašalinimą',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Patvirtinti</strong> išėjimą iš pokalbio',
  '<strong>Confirm</strong> message deletion' => '<strong>Patvirtinti</strong> žinutės pašalinimą',
  'Add user' => 'Pridėti vartotoją',
  'Cancel' => 'Atšaukti',
  'Delete' => 'Ištrinti',
  'Do you really want to delete this conversation?' => 'Ar tikrai norite ištrinti šį pokalbį?',
  'Do you really want to delete this message?' => 'Ar tikrai norite ištrinti šią žinutę?',
  'Do you really want to leave this conversation?' => 'Ar tikrai norite palikti šį pokalbį?',
  'Leave' => 'Palikti',
  'Leave discussion' => 'Išeiti iš pokalbio',
  'Send' => 'Siųsti',
  'There are no messages yet.' => 'Kol kas nėra žinučių.',
  'Write an answer...' => 'Atsakyti...',
);
