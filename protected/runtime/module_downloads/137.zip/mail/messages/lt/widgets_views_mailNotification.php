<?php
return array (
  'Messages' => 'Žinutės',
  'New message' => 'Nauja žinutė',
  'Show all messages' => 'Rodyti visas žinutes',
);
