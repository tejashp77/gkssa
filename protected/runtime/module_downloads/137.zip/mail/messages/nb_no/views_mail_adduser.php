<?php
return array (
  'Add more participants to your conversation...' => '',
  'Close' => 'Lukk',
  'Send' => '',
);
