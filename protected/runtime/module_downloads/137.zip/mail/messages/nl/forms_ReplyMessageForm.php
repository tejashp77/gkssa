<?php
return array (
  'Message' => 'Bericht',
);
