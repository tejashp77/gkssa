<?php
return array (
  'New message in discussion from %displayName%' => 'Nieuw bericht in discussie van %displayName%',
);
