<?php
return array (
  'Groups' => 'Groepen',
  'Members' => 'Leden',
  'Spaces' => '',
  'User Posts' => 'Gebruikersberichten',
);
