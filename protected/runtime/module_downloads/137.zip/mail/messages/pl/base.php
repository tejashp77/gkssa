<?php
return array (
  'Messages' => 'Wiadomości ',
);
