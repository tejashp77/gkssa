<?php
return array (
  'There are no messages yet.' => 'Nie ma jeszcze wiadomości. ',
);
