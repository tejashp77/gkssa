<?php
return array (
  'Message' => 'Сообщение',
);
