<?php
return array (
  'sent you a new message in' => 'отправил вам новое сообщение в',
);
