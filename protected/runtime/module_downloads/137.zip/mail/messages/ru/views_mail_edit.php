<?php
return array (
  'Edit message entry' => 'Редактирование сообщения',
  'Save' => 'Сохранить',
);
