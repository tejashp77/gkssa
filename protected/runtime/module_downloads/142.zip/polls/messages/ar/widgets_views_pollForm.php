<?php
return array (
  'Allow multiple answers per user?' => '',
  'Ask something...' => '',
  'Possible answers (one per line)' => '',
);
