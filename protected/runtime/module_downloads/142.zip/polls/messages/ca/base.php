<?php
return array (
  'Polls' => 'Enquestes',
);
