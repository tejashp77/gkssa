<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} ha creat una nova enquesta i te l\'ha assignada.',
);
