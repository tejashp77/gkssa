<?php
return array (
  'Polls' => 'Ankety',
);
