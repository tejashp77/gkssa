<?php
return array (
  'Could not load poll!' => 'Kunne ikke indlæse afstemning!',
  'Invalid answer!' => 'Ugyldigt svar!',
  'Users voted for: <strong>{answer}</strong>' => 'Brugere stemte på: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Afstemning for flere svar er deaktiveret!',
  'You have insufficient permissions to perform that operation!' => 'Du har utilstrækkelig adgang til at udføre denne opgave!',
);
