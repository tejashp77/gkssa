<?php
return array (
  'Reset my vote' => 'Nulstil min stemme',
  'Vote' => 'Stemme',
  'and {count} more vote for this.' => 'og {count} yderligere stemmer for dette.',
  'votes' => 'stemmer',
);
