<?php
return array (
  'Allow multiple answers per user?' => 'Tillad flere stemmer pr bruger!',
  'Ask something...' => 'Spørg om noget...',
  'Possible answers (one per line)' => 'Mulige svar (et pr linje)',
);
