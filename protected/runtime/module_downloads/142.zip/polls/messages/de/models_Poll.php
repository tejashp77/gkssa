<?php
return array (
  'Answers' => 'Antworten',
  'Multiple answers per user' => 'Mehrfachantworten pro Nutzer',
  'Please specify at least {min} answers!' => 'Bitte gib mindestens {min} Antworten an!',
  'Question' => 'Frage',
);
