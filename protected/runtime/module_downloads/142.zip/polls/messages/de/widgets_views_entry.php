<?php
return array (
  'Reset my vote' => 'Meine Abstimmung zurücksetzen',
  'Vote' => 'Abstimmen',
  'and {count} more vote for this.' => 'und {count} mehr stimmten hierfür ab.',
  'votes' => 'Abstimmungen',
);
