<?php
return array (
  'Polls' => 'Votaciones',
);
