<?php
return array (
  'Ask' => 'Preguntar',
);
