<?php
return array (
  'Reset my vote' => 'Reiniciar mi voto',
  'Vote' => 'Votar',
  'and {count} more vote for this.' => 'y {count} mas votaron por esto.',
  'votes' => 'votos',
);
