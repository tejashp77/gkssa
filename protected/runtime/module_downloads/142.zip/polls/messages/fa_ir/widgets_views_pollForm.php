<?php
return array (
  'Allow multiple answers per user?' => 'اجازه‌ی چند پاسخ به هر کاربر داده‌شود؟',
  'Ask something...' => 'سوال بپرس . . .',
  'Possible answers (one per line)' => 'پاسخ‌های ممکن (هرکدام در یک خط)',
);
