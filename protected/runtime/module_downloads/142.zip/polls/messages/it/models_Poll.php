<?php
return array (
  'Answers' => 'Risposte',
  'Multiple answers per user' => 'Risposte multiple per utente',
  'Please specify at least {min} answers!' => 'Per favore dai almeno {min} risposte!',
  'Question' => 'Domanda',
);
