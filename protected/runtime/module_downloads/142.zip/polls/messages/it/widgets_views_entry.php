<?php
return array (
  'Reset my vote' => 'Resetta il mio voto',
  'Vote' => 'Vota',
  'and {count} more vote for this.' => 'più {count} voti per questo.',
  'votes' => 'voti',
);
