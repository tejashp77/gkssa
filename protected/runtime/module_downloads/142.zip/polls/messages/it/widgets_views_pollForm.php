<?php
return array (
  'Allow multiple answers per user?' => 'Consenti risposte multiple all\'utente?',
  'Ask something...' => 'Chiedi qualcosa...',
  'Possible answers (one per line)' => 'Possibili risposte (una per linea)',
);
