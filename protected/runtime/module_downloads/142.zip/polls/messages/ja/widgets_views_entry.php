<?php
return array (
  'Reset my vote' => '私の投票をリセット',
  'Vote' => '投票',
  'and {count} more vote for this.' => '他{count}人が投票',
  'votes' => '投票',
);
