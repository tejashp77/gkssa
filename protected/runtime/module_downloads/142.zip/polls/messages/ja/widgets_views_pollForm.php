<?php
return array (
  'Allow multiple answers per user?' => 'ユーザーごとに複数の回答を許可しますか？',
  'Ask something...' => '何を質問する...',
  'Possible answers (one per line)' => '可能な回答（1行に1つ）',
);
