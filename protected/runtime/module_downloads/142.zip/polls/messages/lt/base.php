<?php
return array (
  'Polls' => 'Apklausos',
);
