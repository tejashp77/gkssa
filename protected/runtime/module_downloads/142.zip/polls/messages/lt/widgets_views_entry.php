<?php
return array (
  'Reset my vote' => 'Iš naujo nustatyti mano balsavimą',
  'Vote' => 'Balsuoti',
  'and {count} more vote for this.' => 'ir dar {count} balsavimo už tai.',
  'votes' => 'balsai',
);
