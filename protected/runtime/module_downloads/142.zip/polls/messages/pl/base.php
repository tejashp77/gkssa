<?php
return array (
  'Polls' => 'Głosowania ',
);
