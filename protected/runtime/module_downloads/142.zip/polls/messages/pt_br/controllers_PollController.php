<?php
return array (
  'Could not load poll!' => 'Não foi possível carregar enquete!',
  'Invalid answer!' => 'Resposta inválida!',
  'Users voted for: <strong>{answer}</strong>' => 'Usuários votaram em: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'A votação para múltiplas respostas está desabilitada!',
  'You have insufficient permissions to perform that operation!' => 'Você não tem permissões suficientes para executar essa operação!',
);
