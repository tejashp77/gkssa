<?php
return array (
  'Reset my vote' => 'Resetar meu voto',
  'Vote' => 'Votar',
  'and {count} more vote for this.' => 'e mais {count} votos para este.',
  'votes' => 'votos',
);
