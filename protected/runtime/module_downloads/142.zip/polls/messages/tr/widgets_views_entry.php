<?php
return array (
  'Reset my vote' => 'Oyumu sıfırla',
  'Vote' => 'Oyla',
  'and {count} more vote for this.' => 've {count} oy verildi.',
  'votes' => 'oylar',
);
