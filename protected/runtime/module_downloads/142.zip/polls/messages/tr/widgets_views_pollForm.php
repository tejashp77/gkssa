<?php
return array (
  'Allow multiple answers per user?' => 'Birden fazla cevap verilsin mi?',
  'Ask something...' => 'Bir şeyler sor...',
  'Possible answers (one per line)' => 'Olası cevaplar (her satır bir cevap)',
);
