<?php
return array (
  '{userName} created a new {question}.' => '{userName} 创建了一个新问题 {question}.',
);
