<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} 创建了一个新的投票，请你参加!',
);
