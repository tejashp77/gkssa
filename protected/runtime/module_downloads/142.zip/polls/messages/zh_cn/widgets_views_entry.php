<?php
return array (
  'Reset my vote' => '重置我的投票',
  'Vote' => '投票',
  'and {count} more vote for this.' => '另外 {count} 个投票。',
  'votes' => '票',
);
