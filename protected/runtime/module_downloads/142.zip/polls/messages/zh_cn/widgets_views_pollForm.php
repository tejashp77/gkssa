<?php
return array (
  'Allow multiple answers per user?' => '允许答案多选?',
  'Ask something...' => '发起投票',
  'Possible answers (one per line)' => '可选答案（每行一个）',
);
